from django.shortcuts import get_object_or_404,render,redirect
from ..models import productModel
from django.shortcuts import render
#from ..models import Category as CategoryForm
from ..forms.product_form import productForm
#from ..models import Category

def viewProduct(request):
    context={}
    context["products"]=productModel.objects.all()
    return render(request, "product/view.html",context)

def addProduct(request):
    context={}
    form=productForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect( "viewProduct")
    context['form']=form
    return render(request,"product/add.html",context)

def updateProduct(request,id):
    context={}
    obj=get_object_or_404(productModel,id=id)
    form=productForm(request.POST or None,instance=obj)
    if form.is_valid():
        form.save()
        return redirect("viewProduct")
    context["form"]=form
    return render(request,"product/edit.html",context)

def deleteProduct(request,id):
    context={}
    obj=get_object_or_404(productModel,id=id)
    if request.method=="GET":
        obj.delete()
        return redirect("viewProduct")
    return render(request,"product/view.html",context)