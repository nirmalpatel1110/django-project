from django.shortcuts import get_object_or_404,render,redirect
from ..models import saleModel
from django.shortcuts import render
#from ..models import Category as CategoryForm
from ..forms.sales_form import saleForm
#from ..models import Category

def viewSale(request):
    context={}
    context["sales"]=saleModel.objects.all()
    return render(request,"sale/view.html",context)

def addSale(request):
    context={}
    form=saleForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect( "viewSale")
    context['form']=form
    return render(request,"sale/add.html",context)

def updateSale(request,id):
    context={}
    obj=get_object_or_404(saleModel,id=id)
    form=saleForm(request.POST or None,instance=obj)
    if form.is_valid():
        form.save()
        return redirect("viewsale")
    context["form"]=form
    return render(request,"sale/edit.html",context)

def deleteSale(request,id):
    context={}
    obj=get_object_or_404(saleModel,id=id)
    if request.method=="GET":
        obj.delete()
        return redirect("viewSale")
    return render(request,"sale/view.html",context)