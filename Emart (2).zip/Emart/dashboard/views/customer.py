from django.shortcuts import get_object_or_404,render,redirect
from ..models import customerDetails
from django.shortcuts import render
#from ..models import Category as CategoryForm
from ..forms.customer_form import CustomerForm
#from ..models import Category

def view_Customer(request):
    context={}
    context["details"]=customerDetails.objects.all()
    return render(request, "customer/view.html",context)

def add_Customer(request):
    context={}
    form=CustomerForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect("view_Customer")
    context['form']=form
    return render(request,"customer/add.html",context)

def update_Customer(request,id):
    context={}
    obj=get_object_or_404(customerDetails,id=id)
    form=CustomerForm(request.POST or None,instance=obj)
    if form.is_valid():
        form.save()
        return redirect("view_Customer")
    context["form"]=form
    return render(request,"customer/edit.html",context)

def delete_Customer(request,id):
    context={}
    obj=get_object_or_404(customerDetails,id=id)
    if request.method=="GET":
        obj.delete()
        return redirect("view_Customer")
    return render(request,"customer/view.html",context)