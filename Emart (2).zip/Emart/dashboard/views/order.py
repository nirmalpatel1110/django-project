from django.shortcuts import get_object_or_404,render,redirect
from ..models import orderModel
from django.shortcuts import render
#from ..models import Category as CategoryForm
from ..forms.order_form import orderForm
#from ..models import Category

def viewOrder(request):
    context={}
    context["orders"]=orderModel.objects.all()
    return render(request, "order/view.html",context)

def addOrder(request):
    context={}
    form=orderForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect( "viewOrder")
    context['form']=form
    return render(request,"order/add.html",context)

def updateOrder(request,id):
    context={}
    obj=get_object_or_404(orderModel,id=id)
    form=orderForm(request.POST or None,instance=obj)
    if form.is_valid():
        form.save()
        return redirect("viewOrder")
    context["form"]=form
    return render(request,"order/edit.html",context)

def deleteOrder(request,id):
    context={}
    obj=get_object_or_404(orderModel,id=id)
    if request.method=="GET":
        obj.delete()
        return redirect("viewOrder")
    return render(request,"order/view.html",context)