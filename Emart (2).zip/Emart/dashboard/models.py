#from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import AbstractUser
#from django.contrib.auth.models import User, Group
# Create your models here.

class UserModel(AbstractUser):
    pass

#class register(models.Model):
 #   name=models.CharField(max_length=30)
  #  email=models.CharField(max_length=50)
   # age=models.CharField(max_length=10)
    #password=models.CharField(max_length=20)
    #confirm=models.CharField(max_length=20)
    


class CategoryModel(models.Model):
    title=models.CharField(max_length=200)  
    description= models.TextField()

class customerDetails(models.Model):
    id = models.AutoField(primary_key=True)
    fname=models.CharField(max_length=30)
    lname=models.CharField(max_length=30)
    email=models.CharField(max_length=30)
    mobileNo=models.CharField(max_length=30)
    location=models.CharField(max_length=30)

class billModel(models.Model):
    id = models.AutoField(primary_key=True)
    cname=models.CharField(max_length=30)
    product=models.CharField(max_length=30)
    price=models.DecimalField(max_digits=10,decimal_places=2)
    status=models.CharField(max_length=10)

class productModel(models.Model):
    id = models.AutoField(primary_key=True)
    cname=models.CharField(max_length=30)
    pname=models.CharField(max_length=30)
    dis=models.CharField(max_length=10)
    price=models.DecimalField(max_digits=10,decimal_places=2)
    Disprice=models.DecimalField(max_digits=10,decimal_places=2)

class orderModel(models.Model):
    id = models.AutoField(primary_key=True)
    cname=models.CharField(max_length=30)
    pname=models.CharField(max_length=30)
    totalItem=models.DecimalField(max_digits=10,decimal_places=2)
    totalprice=models.DecimalField(max_digits=10,decimal_places=2)
    status=models.CharField(max_length=20)

class saleModel(models.Model):
    id = models.AutoField(primary_key=True)
    product=models.CharField(max_length=30)
    saleDate=models.CharField(max_length=30)
    saleEnd=models.CharField(max_length=30)
    dis=models.DecimalField(max_digits=10,decimal_places=2)
    price=models.DecimalField(max_digits=10,decimal_places=2)
    
  


def __str__(self):
    return self.title

class Meta:
    db_table="dashboard_user"
   