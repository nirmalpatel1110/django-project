from django.urls import path
from ..views.sale import *
saleURL=[
    path('viewSale/',viewSale,name="viewSale"),
    path('addSale/',addSale,name="addSale"),  
    path('updateSale/<id>',updateSale,name="updateSale"), 
    path('deleteSale/<id>',deleteSale,name="deleteSale"), 
]