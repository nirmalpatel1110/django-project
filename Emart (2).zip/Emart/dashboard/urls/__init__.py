from .auth import authUrls
from .category import categoryURL
from .customer import customerURL
from .bill import billURL
from .product import productURL
from .order import orderURL
from .sale import saleURL

urlpatterns=authUrls+categoryURL+customerURL+billURL+productURL+orderURL+saleURL