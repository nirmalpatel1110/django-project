from django.urls import path
from ..views.product import *
productURL=[
    path('viewProduct/',viewProduct,name="viewProduct"),
    path('addProduct/',addProduct,name="addProduct"),  
    path('updateProduct/<id>',updateProduct,name="updateProduct"), 
    path('deleteProduct/<id>',deleteProduct,name="deleteProduct"), 
]