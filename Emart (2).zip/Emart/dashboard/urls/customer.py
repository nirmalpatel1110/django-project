from django.urls import path
from ..views.customer import *
customerURL=[
    path('view_Customer/',view_Customer,name="view_Customer"),
    path('add_Customer/',add_Customer,name="add_Customer"),  
    path('update_Customer/<id>',update_Customer,name="update_Customer"), 
    path('delete_Customer/<id>',delete_Customer,name="delete_Customer"), 
]