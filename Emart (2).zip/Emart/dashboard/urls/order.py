from django.urls import path
from ..views.order import *
orderURL=[
    path('viewOrder/',viewOrder,name="viewOrder"),
    path('addOrder/',addOrder,name="addOrder"),  
    path('updateOrder/<id>',updateOrder,name="updateOrder"), 
    path('deleteOrder/<id>',deleteOrder,name="deleteOrder"), 
]