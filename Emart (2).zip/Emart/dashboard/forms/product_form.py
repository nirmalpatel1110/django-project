from socket import fromshare
from django import forms
from ..models import productModel
from django.db import models
#from crispy_forms.helper import FormHelper
#from crispy_forms.layout import Layout, ButtonHolder, Submit

class productForm(forms.ModelForm):
    
    class Meta:
        model=productModel

        fields=[
            "cname",
            "pname",
            "dis",
            "price",
            "Disprice",
        ]