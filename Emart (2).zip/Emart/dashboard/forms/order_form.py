from socket import fromshare
from django import forms
from ..models import orderModel
from django.db import models
#from crispy_forms.helper import FormHelper
#from crispy_forms.layout import Layout, ButtonHolder, Submit

class orderForm(forms.ModelForm):
    
    class Meta:
        model=orderModel

        fields=[
            "cname",
            "pname",
            "totalItem",
            "totalprice",
            "status",
        ]