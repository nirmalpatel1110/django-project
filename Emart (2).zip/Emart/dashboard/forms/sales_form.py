from socket import fromshare
from django import forms
from ..models import saleModel
from django.db import models
#from crispy_forms.helper import FormHelper
#from crispy_forms.layout import Layout, ButtonHolder, Submit

class saleForm(forms.ModelForm):
    
    class Meta:
        model=saleModel

        fields=[
            "product",
            "saleDate",
            "saleEnd",
            "dis",
            "price",
        ]